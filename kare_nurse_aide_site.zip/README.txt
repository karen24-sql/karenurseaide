
HOW TO HOST YOUR SITE USING NETLIFY:

1. Go to https://app.netlify.com/signup and sign up (you can use your GitHub or email).
2. Click "Add new site" > "Deploy manually".
3. Drag and drop this folder (unzipped) into the upload area.
4. Netlify will generate a link like https://your-site-name.netlify.app

That's it! Your site is now live.

Contact: mikenson.dorcinvil@fora.travel if you need help.
